/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.CorporationAdmin;

import Business.EcoSystem;
import Business.Threshold;

/**
 *
 * @author aliasgar
 */
public class Bill {

    private double eBill;
    private double gBill;
    private double wBill;

    public double geteBill() {
        return eBill;
    }

    public void seteBill(double eBill) {
        this.eBill = eBill;
    }

    public double getgBill() {
        return gBill;
    }

    public void setgBill(double gBill) {
        this.gBill = gBill;
    }

    public double getwBill() {
        return wBill;
    }

    public void setwBill(double wBill) {
        this.wBill = wBill;
    }

}
